package actions;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	Connection connect=null;
	java.sql.PreparedStatement pst;
	
	public static Connection databaseConnect() {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");

	     // variables
	     final String url = "jdbc:mysql:///PETS_ROLES";
	     final String user = "root";
	     final String password = "23-Oct.@2000";
	     
	     // establish the connection
	     Connection connect = DriverManager.getConnection(url, user, password);
	     
	     // display status message
	     if (connect == null) {
	        System.out.println("JDBC connection is not established");
	        
	     } else
	        System.out.println("Congratulations," + 
	             " JDBC connection is established successfully.\n");
	     return connect;
		}
		catch(Exception e) {
			System.out.println(e);
			return null;
		}
	}
	
	 

}
